Contributing
===============
The package welcomes contributions! Primary development happens through `GitHub:Nick-Gale/NetworkAnalysis <http://www.github.com/Nick-Gale/NetworkAnalysis>`_. Issues may be raised there and pull-requests may be submitted. 

Requests and support issues may be emailed to: nick.gale1993@gmail.com; nmg41@cam.ac.uk; rb643@cam.ac.uk; sje30@cam.ac.uk.
