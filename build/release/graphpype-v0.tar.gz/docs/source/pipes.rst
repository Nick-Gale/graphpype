Recipes and Pipelines
=====================

GraphPype aims to make research transparent and reproducible. We introduce the Pipeline and Recipe classes to help standardise the analysis pipeline used for neuroimaging while front-loading the parameters and package versions to enable transparancey and portability between research groups.


