.. GraphPype documentation master file, created by
   sphinx-quickstart on Thu Apr 18 10:54:14 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to GraphPype's documentation!
=====================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   modules
   gettingstarted 
   contributing
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
