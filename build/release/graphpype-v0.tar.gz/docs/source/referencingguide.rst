Referencing
===============
We aim to publish GraphPype as a journal article - please keep an eye out for the DOI. Please also include a reference to the GitHub page and commit used in your project.
